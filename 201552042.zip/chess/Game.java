package chess;
import java.util.Scanner;
   class Game
    {
	  Board boar=new Board();
	  Game()
	    {
		   //Board Initialization.
		   boar.board[0][0].p1=boar.r[0];
		   boar.board[0][1].p1=boar.n[0];
		   boar.board[0][2].p1=boar.b[0];
		   boar.board[0][3].p1=boar.k[0];
		   boar.k[0].x=0;
		   boar.k[0].y=3;
		   boar.board[0][4].p1=boar.q[0];
		   boar.board[0][5].p1=boar.b[1];
		   boar.board[0][6].p1=boar.n[1];
		   boar.board[0][7].p1=boar.r[1];
		   for(int i=0;i<16;i++)
		    {
			  if(i<8)
			    {  
                  boar.board[1][i].p1=boar.p[i];
                  boar.p[i].x=1;
                  boar.p[i].y=i;
				}				  
              else
			    {
				 boar.board[6][i-8].p1=boar.p[i];
                 boar.p[i].x=6;
                 boar.p[i].y=i-8;				 
                }				 
		    }
		   boar.board[7][0].p1=boar.r[2];
		   boar.board[7][1].p1=boar.n[2];
		   boar.board[7][2].p1=boar.b[2];
		   boar.board[7][3].p1=boar.q[1];
		   boar.board[7][4].p1=boar.k[1];
		   boar.k[1].x=7;
		   boar.k[1].y=4;
		   boar.board[7][5].p1=boar.b[3];
		   boar.board[7][6].p1=boar.n[3];
		   boar.board[7][7].p1=boar.r[3];
		}
	  public static void main(String args[])
	    {
		  Scanner scan=new Scanner(System.in);
		  Game g1=new Game();
		  String color="white";
		  System.out.println("Note:\n 1.) Capital letter means pieces of white player.");
		  System.out.println(" 2.) Lower letter means pieces of black player.");
		  System.out.println(" 3.) Co-ordinates of left Rook of white player is (0,0) other coordinates are according to this reference.");
		  while(true)//check condition wheteher both kings are alive or not.
		    {
		      if(color=="white")
		        {
				  g1.boar.display();
			      System.out.println(" Turn of white player \n Enter initial positon");
			      int xi=scan.nextInt();
			      int yi=scan.nextInt();
				  if(((xi>=0)&&(xi<=7))&&((yi>=0)&&(yi<=7)))//checking whether initial position is valid or not.
				    {
				      System.out.println(" Enter final position");
			          int xf=scan.nextInt();
			          int yf=scan.nextInt();
					  if(((xf>=0)&&(xf<=7))&&((yf>=0)&&(yf<=7)))//checking whether final position is valid or not.
					    {
				          //color is passed to check whether the piece at given position is your piece or not; 
			              boolean check=g1.boar.move(color,xi,yi,xf,yf);
			              if(check)
				            {
							  System.out.println("move successful");
					          color="black";//if move is successful change the turn.
					        }
				        }
					  else
						System.out.println("invalid final position");
					}
				  else
				    {
					  System.out.println("invalid initial position");  
				    }
				}
			  else
			    {
				  g1.boar.display();
			      System.out.println(" Turn of black player \n Enter initial positon");
			      int xi=scan.nextInt();
			      int yi=scan.nextInt();
				  if(((xi>=0)&&(xi<=7))&&((yi>=0)&&(yi<=7)))//checking whether initial position is valid or not.
				    {
				      System.out.println(" Enter final position");
			          int xf=scan.nextInt();
			          int yf=scan.nextInt();
					  if(((xf>=0)&&(xf<=7))&&((yf>=0)&&(yf<=7)))//checking whether final position is valid or not.
					    {
				          //color is passed to check whether the piece at given position is your piece or not; 
			              boolean check=g1.boar.move(color,xi,yi,xf,yf);
						  if(check)
						    {
							  System.out.println("move successful");
					          color="white";//if move become successful changing the turn.
					        }
						  else
						    {
							  System.out.println("invalid move");  
						    }
						}
					  else
						System.out.println("invalid final position");
					}
				  else
				    {
					  System.out.println("invalid initial position");  
				    }	  
			    }
			}
		}
	}