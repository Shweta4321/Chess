package chess;
class Square
    {
	  //p1 is the reference to piece on the specified Square.
	  Piece p1;
	}