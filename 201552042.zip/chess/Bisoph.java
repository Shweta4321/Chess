package chess;
   class Bisoph extends Piece
    {
	  Bisoph(String col)
	    {
          color=col;
		  status=0;
		  type ='b';
	    }
      boolean pieceValidMove(int xi,int yi,int xf,int yf)
	    {
		   //checking whether piece can move to fianl position or not.
		   if((xf-xi)==(yf-yi)||(xf-xi)==(yi-yf))
			return true;
		   else
			return false;     
	    }	  
    } 
