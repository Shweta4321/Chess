package chess;
  class Board
    {
	   Square board[][]=new Square[8][8];
	   King k[]=new King[2];
	   Queen q[]=new Queen[2];
	   Bisoph b[]=new Bisoph[4];
	   Rook r[]=new Rook[4];
	   Knight n[]=new Knight[4];
	   Pawn p[]=new Pawn[16];
	  int i,j;
	  {
	   for(i=0;i<8;i++)
	    {
		  for(j=0;j<8;j++)
		    { 
			  board[i][j]=new Square();  
		    }	 		  
	    }
	   k[0]=new King("white");
	   k[1]=new King("black");
	   q[0]=new Queen("white");
	   q[1]=new Queen("black");
	   b[0]=new Bisoph("white");
	   b[1]=new Bisoph("white");
	   b[2]=new Bisoph("black");
	   b[3]=new Bisoph("black");
	   r[0]=new Rook("white");
	   r[1]=new Rook("white");
	   r[2]=new Rook("black");
	   r[3]=new Rook("black");
	   n[0]=new Knight("white");
	   n[1]=new Knight("white");
	   n[2]=new Knight("black");
	   n[3]=new Knight("black");
	   for(i=0;i<8;i++)
		p[i]=new Pawn("white");
	   for(i=8;i<16;i++)
		p[i]=new Pawn("black");
	  }
	  Piece whichPiece(int xi,int yi)
	    {
		  return (board[xi][yi].p1);
	    }
	  void update(int xi,int yi,int xf,int yf)
	    {
		  //note :in valid move we will check the color of piece at destination so need not to check here.
		  if(board[xf][yf].p1==null)
		    { 
			  board[xf][yf].p1=board[xi][yi].p1;
			  board[xi][yi].p1=null;
		    }
		  else
		    { 
		      board[xf][yf].p1.status=-1;
			  board[xf][yf].p1=board[xi][yi].p1;
			  board[xi][yi].p1=null;
			}
	    }
	  boolean move(String col,int xi,int yi,int xf,int yf)
	    {
		  Piece pi=whichPiece(xi,yi);
		  //checking piece hai ya initial position.
		  if(pi==null)
		    {
			  System.out.println("No piece at given place");
			  return false;
			}
		 //checking piece apna hai k nhi initial position pe.
		  else if((pi!=null)&&(pi.color!=col))
		    {
			  System.out.println("not your piece at given initial position");
			  return false;  
		    }
		  //checking final position pe ja sakte hai k nhi.
		  else
		    {
			  //piece jai sakta hai k nhi final position pe.
			  if(pi.pieceValidMove(xi,yi,xf,yf))
			    {
				  int xd,yd,dec,change;
				  //check according to the piece beech mai koi hai k nhi.
			//Piece at given initial position is ROOK.
				  if(pi.type=='r')
				    {
					  xd=xf-xi;
					  yd=yf-yi;
					  //check in which direction rook in moving.
					  if(xd==0)
					    { 
					      //rook is moving horizontally.
					      if(yd>0)
						    dec=1;
					      else if(yd<0)
						    dec=-1;
					      else
							return false;
						  for(i=yi+dec;i!=yf;i+=dec)
						    {
							  if(board[xi][i].p1!=null)
                               break;
						    }
						  if(i==yf)
		                    {
							  //beech mai to kuch nhi h ab final pe check karenge
                              if(board[xf][yf].p1==null)
							    {						
                                  //final position empty hai.							
							      update(xi,yi,xf,yf);
							      return true;
							    }
						      else if((board[xf][yf].p1!=null)&&(board[xf][yf].p1.color!=col))
							    {
								  //final position pe doosra player hai.
							      update(xi,yi,xf,yf);
							      return true;
							    }
						      else
							    {
								  //final position pe apna player hai.
							     System.out.println("invalid move");
							     return false;
							    }
						    }
                          else
						    {
							  //beech mai kuch aa gya is liye final position tk nhi ja sakta.	
						      System.out.println("invalid move");
                              return false;							  
						    }
						}
					   else 
					    {
						  //rook is moving vertically.
					      if(xd>0)
						      dec=1;
					      else
						    dec=-1;
						  for(i=xi+dec;i!=xf;i=i+dec)
						    {
							  if(board[i][yi].p1!=null)
                               break;
						    }
						  if(i==xf)
		                    {
							  //beech mai koi nhi hai.
                              if(board[xf][yf].p1==null)
							    {						
                                  //final position pe b koi nhi hai.							
							      update(xi,yi,xf,yf);
							      return true;
							    }
						      else if((board[xf][yf].p1!=null)&&(board[xf][yf].p1.color!=col))
							    {
								  //final position pe dosri player ka piece hai.
							      update(xi,yi,xf,yf);
							      return true;
							    }
						      else
							    {
								  //final position pe apna hi player hai.
							      System.out.println("invalid move");
							      return false;
							    }
						    }
                          else
						    {
							  // beech mai kuch aa gya isliye final position tk nhi pahunch sakte.
						      System.out.println("invalid move");
                              return false;							  
						    }
						}  
					}
              //Piece at given initial position is KNIGHT.
				  else if(pi.type=='n')
				    {
					  if(board[xf][yf].p1==null)
					    {								  
						  update(xi,yi,xf,yf);
						  return true;
					    }
					  else if((board[xf][yf].p1!=null)&&(board[xf][yf].p1.color!=col))
					    {
					     update(xi,yi,xf,yf);
						 return true;
						}
					  else
					    {
						  System.out.println("invalid move");  
						  return false;
					    }	
				    }
              // Piece at given initial position is BISHOP. 
				  else if(pi.type=='b')
				    {
					  xd=xf-xi;
					  yd=yf-yi;
					  if(xd>0)
					    {
						  //bishop is moving in the direction in which x is increasing.
						  if(yd>0)
							dec=1; 
                          else
                            dec=-1;
                          for(i=xi+1,j=yi+dec;i!=xf;i++,j+=dec)	
							{  
							  if(board[i][j].p1!=null)
								break;
						    }
					    }
					   else if(xd<0)
					    {
						  //bishop is moving in the direction in which x is direction.
						  if(yd>0)
							dec=1; 
                          else
                            dec=-1;
                          for(i=xi-1,j=yi+dec;i!=xf;i--,j+=dec)	
							{  
							  if(board[i][j].p1!=null)
								break;
						    }		
					    }
                       else 
					    {
						  //initial and final position is same.
					      return false;//when initial and final position same.
						}
                       //checking of final position in position in both cases.
                       if(i==xf)
						{
						  //beech mai kuch nhi hai ,bss ab final position pe check krna hai.
						  if(board[xf][yf].p1==null)
					        {								  
							  //final position pe b koi nhi h.
						      update(xi,yi,xf,yf);
						      return true;
					        }
					      else if((board[xf][yf].p1!=null)&&(board[xf][yf].p1.color!=col))
					        {
							  //final position pe doosri player ka piece hai.
					          update(xi,yi,xf,yf);
						      return true;
						    }
					      else
					        {
							  //final position pe apna hi piece hai.
						       System.out.println("invalid move");  
						       return false;
					        }
						}
                       else
					    {
					      System.out.println("invalid move");  
						  return false;
						}					   
				    }
            //piece at given initial position is QUEEN.
				  else if(pi.type=='q')
				    {
				      // check whether the queen is moving straight or diagonally.
					  xd=xf-xi;
					  yd=yf-yi;
					  if(xd==0||yd==0)
					    {
						  //moving horizontally or vertically.
						  if(xd==0)
					        { 
					          if(yd>0)
						       dec=1;
					          else if(yd<0)
						       dec=-1;
					          else
							   return false;
						      for(i=yi+dec;i!=yf;i+=dec)
						        {
							      if(board[xi][i].p1!=null)
                                    break;
						        }
						      if(i==yf)
		                        {
                                  if(board[xf][yf].p1==null)
							        {								  
							          update(xi,yi,xf,yf);
							          return true;
							        }
						          else if((board[xf][yf].p1!=null)&&(board[xf][yf].p1.color!=col))
							        {
							          update(xi,yi,xf,yf);
							          return true;
							        }
						          else
							        {
							          System.out.println("invalid move");
							          return false;
							        }
						        }    
                              else
						        {
						          System.out.println("invalid move");
                                  return false;							  
						        }
						    }
					      else
					        {
					          if(xd>0)
						       dec=1;
					          else
						       dec=-1;
						      for(i=xi+dec;i!=xf;i=i+dec)
						        {
							      if(board[i][yi].p1!=null)
                                    break;
						        }
						      if(i==xf)
		                        {
                                 if(board[xf][yf].p1==null)
							        {								  
							         update(xi,yi,xf,yf);
							         return true;
							        }
						         else if((board[xf][yf].p1!=null)&&(board[xf][yf].p1.color!=col))
							        {
							          update(xi,yi,xf,yf);
							          return true;
							        }
						         else
							        {
							          System.out.println("invalid move");
							          return false;
							        }
						        }
							   else
						        {
						          System.out.println("invalid move");
                                  return false;							  
						        }
						    }
						}
					  else 
					    {
						  //queen moving daigonally.
						   if(xd>0)
					        {
						      if(yd>0)
							   dec=1; 
                              else
                               dec=-1;
                              for(i=xi+1,j=yi+dec;i!=xf;i++,j+=dec)	
							    {  
							      if(board[i][j].p1!=null)
								    break;
						        }							
					        }
					      else if(xd<0)
					        {
						      if(yd>0)
							   dec=1; 
                              else
                               dec=-1;
                              for(i=xi-1,j=yi+dec;i!=xf;i--,j+=dec)	
							    {  
							      if(board[i][j].p1!=null)
								    break;
						        }		
					        }
                          else if(xd==0)
						    {
					          return false;//when initial and final position same.
							}
						  //checking final position in two diagonal cases.
						  if(i==xf)
						    {
							  if(board[xf][yf].p1==null)
					            {								  
						          update(xi,yi,xf,yf);
						          return true;
					            }
					          else if((board[xf][yf].p1!=null)&&(board[xf][yf].p1.color!=col))
					            {
					              update(xi,yi,xf,yf);
						          return true;
						        }
					          else
					            {
						          System.out.println("invalid move");  
						          return false;
					            }
						    }
                           else
						    {
							  System.out.println("invalid move");  
							  return false;
						    }
					    }
    				}
            // Piece at given location is KING.
				  else if(pi.type=='k')
				    {
					  if(board[xf][yf].p1==null)
					    {
						  update(xi,yi,xf,yf);  
						  return true;
					    }
					  else if((board[xf][yf].p1!=null)&&(board[xf][yf].p1.color!=col))
					    {
						  update(xi,yi,xf,yf);  
						  return true;
					    }
					  else
					    {
						  System.out.println("invalid move");
                          return false;						  
					    }
				    }
            //Piece at given initial position is Pawn.					
				  else if(pi.type=='p')
				    {
					  xd=xf-xi;
					  yd=yf-yi;
					  if(yd==0)
					    {
						  if(xd>0)
							dec=1;
						  else if(xd<0)
							dec=-1;
						  else
							return false;
						  for(i=xi+dec;i!=xf;i+=dec)
						    {
							  if(board[i][yi].p1!=null)
                                break;								  
						    }
						  if(i==xf)
						    {
							  if(board[xf][yf].p1==null)
							    {
								  update(xi,yi,xf,yf);
								  return true;
							    }
							  else
							    {
								  System.out.println("invalid move");
                                  return false;								  
							    }
						    }
						  else
						    {
                              System.out.println("invalid move"); 				
							  return false;
							}
					    }
					  else
					    {
						   if((board[xf][yf].p1!=null)&&(board[xf][yf].p1.color!=col))
						    {
							  update(xi,yi,xf,yf);
                              return true;							  
						    }
						   else
						    {
							  System.out.println("invalid move");
                              return false;							  
						    }		  
					    }
				    }
				  else
				    { 
                      //kuch bhi random ho jae jo hamari condition mai na ho.				
					  return false;
			        }
				}
			  else
			    {
				  //piece ka hi valid move nhi hai.
				  System.out.println("invalid move");  
				  return false;
			    }
			}
        }			
	  void display()
	    {
		   int i,j;
		   System.out.println("\n");
		   for(i=0;i<=7;i++)
		    {
			  System.out.print("\t\t\t\t");
			  for(j=0;j<=7;j++)
			    {
				  if(board[i][j].p1==null)
					System.out.print("-   ");  
				  else if(board[i][j].p1.color=="white")
					System.out.print(Character.toUpperCase(board[i][j].p1.type)+"   "); 
                  else
                    System.out.print(board[i][j].p1.type+"   "); 					  
				}
			  System.out.println("\n");
			}
	    }
 	}